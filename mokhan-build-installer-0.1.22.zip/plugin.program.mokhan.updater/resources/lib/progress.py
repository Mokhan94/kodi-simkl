import xbmc
import xbmcgui


class InstallCancelled(Exception):
    pass


class InstallProgress(xbmcgui.WindowXMLDialog):
    TITLE = 101
    VERSION = 102
    STAGE = 103
    DETAIL = 104
    PERCENT = 105
    PROGRESS = 201
    CANCEL = 301

    def __init__(self, *args, **kwargs):
        self._cancelled = False
        self._cancellable = True
        self._ready = False
        self._pending = None
        super(InstallProgress, self).__init__(*args, **kwargs)

    def onInit(self):
        self._ready = True
        self.getControl(self.TITLE).setLabel('KODI SIMKL BUILD')
        if self._pending:
            self.update(*self._pending)

    def onClick(self, control_id):
        if control_id == self.CANCEL and self._cancellable:
            self._cancelled = True

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216) and self._cancellable:
            self._cancelled = True

    @property
    def cancelled(self):
        return self._cancelled

    def set_cancellable(self, enabled):
        self._cancellable = bool(enabled)
        if self._ready:
            control = self.getControl(self.CANCEL)
            control.setEnabled(self._cancellable)
            control.setLabel('Cancel' if self._cancellable else 'Installing…')

    def update(self, percent, stage, detail='', version=''):
        percent = max(0, min(100, int(percent)))
        self._pending = (percent, stage, detail, version)
        if not self._ready:
            return
        self.getControl(self.VERSION).setLabel('VERSION {}'.format(version) if version else '')
        self.getControl(self.STAGE).setLabel(stage)
        self.getControl(self.DETAIL).setLabel(detail)
        self.getControl(self.PERCENT).setLabel('{}%'.format(percent))
        self.getControl(self.PROGRESS).setPercent(percent)
        xbmc.sleep(10)

    def check_cancelled(self):
        if self._cancelled:
            raise InstallCancelled('Update cancelled. No build files were changed.')


class StandardProgress:
    """Fallback used if a device cannot load the custom XML window."""

    def __init__(self):
        self.dialog = xbmcgui.DialogProgress()
        self._cancellable = True

    def show(self):
        self.dialog.create('Kodi Simkl Build', 'Preparing installer…')

    def close(self):
        self.dialog.close()

    def set_cancellable(self, enabled):
        self._cancellable = bool(enabled)

    def update(self, percent, stage, detail='', version=''):
        heading = '{}{}'.format(stage, ' — v{}'.format(version) if version else '')
        self.dialog.update(int(percent), heading, detail)

    def check_cancelled(self):
        if self._cancellable and self.dialog.iscanceled():
            raise InstallCancelled('Update cancelled. No build files were changed.')


def create_progress(addon_path):
    try:
        window = InstallProgress(
            'install-progress.xml', addon_path, 'Default', '1080i')
        window.show()
        xbmc.sleep(100)
        return window
    except Exception:
        fallback = StandardProgress()
        fallback.show()
        return fallback
